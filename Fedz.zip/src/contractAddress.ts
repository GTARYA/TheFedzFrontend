
// Replace with your actual contract address and ABI
export const PoolSwapTestAddress = '0x841B5A0b3DBc473c8A057E2391014aa4C4751351';
export const PoolModifyLiquidityTestAddress = '0x39BF2eFF94201cfAA471932655404F63315147a4';
export const HookAddress = 	'0x4E4a9A0C097427A4A72B1386A031fd411adf8aC0';
export const MockUSDTAddress ='0x0f1D1b7abAeC1Df25f2C4Db751686FC5233f6D3f';
export const MockFUSDAddress = '0xc7c06a77b481869ecc57E5432D03c3661406424D';
export const TimeSlotSystemAddress = '0x527A1ceA21F996F0990F977602B62371a37c71DC';
export const MockERC721Address = '0x5E17291436a4a87DFA9Cc75f79174E5Ff587B753';