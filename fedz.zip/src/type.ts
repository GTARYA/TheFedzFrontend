export interface TokenInfo {
    address: string;
    name: string;
    decimals: number;
  }