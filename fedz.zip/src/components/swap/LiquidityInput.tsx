import React from 'react'

type Props = {}

function LiquidityInput({}: Props) {
  return (
    <div>LiquidityInput</div>
  )
}

export default LiquidityInput